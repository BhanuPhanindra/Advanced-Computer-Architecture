package memoryBlocks;

public class memry_bus
{

    private long memBusIsBusyTill;

    public memry_bus()
    {
        this.memBusIsBusyTill = 0;
    }

    public boolean isBusBusy(long clkCycleCount)
    {
        if (this.memBusIsBusyTill > clkCycleCount)
            return true;
        
        return false;
    }

    public void updateBusBusyTill(long clkCycleCount)
    {
        this.memBusIsBusyTill = clkCycleCount;
    }

    public long getBusBusyTill()
    {
        return this.memBusIsBusyTill;
    }
}