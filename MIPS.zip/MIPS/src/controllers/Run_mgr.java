package controllers;

import java.util.*;

import inputParsers.ins_parsing;
import instructions.abstrct.data_instr;

public class Run_mgr 
{	
	public static Run_mgr run_manager = null;
	
	private int instr_count =0;
	private Map<String,Integer> label_map = null;
	private Map<Integer, String> instr_list = null;
	
	private Run_mgr() 
	{
		this.instr_count = 0;
		this.instr_list = new HashMap<>();
		this.label_map = new HashMap<>();
	}
	
	public static Run_mgr get_inst() 
	{
		if(run_manager == null)
			run_manager = new Run_mgr();
		return run_manager;
	}

	public int get_addr_label(String label)
	{
		if(label_map.containsKey(label))
			return label_map.get(label);
		else
			return -1;
	}

	public data_instr get_instr_addr(int addr) 
	{
		if(instr_list.containsKey(addr))
		{
			String inst_Str= instr_list.get(addr);
			return ins_parsing.getInstructionObj(inst_Str);
		}
		else
			return null;
	}

	public int get_inst_count() 
	{
		return instr_count;
	}

	public Map<String, Integer> get_map() 
	{
		return label_map;
	}
	
	public void set_inst_count(int instruct_count) 
	{
		instr_count = instruct_count;
	}

	public void set_instr_list(Map<Integer, String> instruct_list) 
	{
		this.instr_list = instruct_list;
	}
	
	public void set_label_map(Map<String, Integer> label_map) 
	{
		this.label_map = label_map;
	}

	public Map<Integer, String> get_inst_list() 
	{
		return instr_list;
	}

	public void add_label_map(String label, int addr)
	{
		this.label_map.put(label, addr);
	}
	
	public void add_instr(int add, String inst_str)
	{
		this.instr_list.put(add, inst_str);
		this.instr_count++;
	}
}
