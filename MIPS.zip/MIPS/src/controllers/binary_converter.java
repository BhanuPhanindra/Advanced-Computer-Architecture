package controllers;

public class binary_converter 
{
	public static int toInt(String data)
	{
		int val = 0;
		for(int i = 1; i < data.length(); i++)
			val = val * 2 + (data.charAt(i)-'0');
		
		if(data.charAt(0) == '1')
			val = val + Integer.MIN_VALUE;
		return val;
	}
	
	public static String to_binary(int info)
	{
		char bin_str[] = new char[32];
		int ind = 31;
		long num=0;
		
		for(int i = 0 ; i < bin_str.length; i++)
			bin_str[i] = '0';
		
		if(info < 0)	{
			num = info + Integer.MIN_VALUE;
			bin_str[0] = '1';
		}else {
			num = info;
			bin_str[0] = '0';
		}
		
		while(num != 0) {
			int mod = (int) (num%2);
			if(mod == 0)
				bin_str[ind] = '0';
			else
				bin_str[ind] = '1';
			ind--;
			num = num/2;
		}
		return new String(bin_str).trim();
	}
}
