package controllers;

public class configuration_management	{
	
	private int inst_cache_blocks;
	private int multiplier_cycles;
	private int inst_cache_size;
	private int mltiplier_units;
	private int divider_cycles;
	private int divider_units;
	private int add_Cycles;
	private int add_Units;
	
	private static configuration_management config_mgr = null;
	
	private configuration_management() {
		this.inst_cache_blocks = this.inst_cache_size = 0;
		this.mltiplier_units = this.multiplier_cycles = 0;
		this.divider_cycles = this.divider_units = 0;
		this.add_Units = this.add_Cycles = 0;
	}
	
	public synchronized static configuration_management getInstance() 	{
		if(config_mgr == null)
			config_mgr = new configuration_management();
		
		return config_mgr;
	}
	
	public int get_add_Units() 	{
		return this.add_Units;
	}
	
	public int get_add_Cycles() 	{
		return this.add_Cycles;
	}
	
	
	public void set_add_units(int fp_add_units) 	{
		add_Units = fp_add_units;
	}
	
	public int get_mult_units() 	{
		return mltiplier_units;
	}
	
	public void set_add_cycles(int fp_add_Cycles) 	{
		add_Cycles = fp_add_Cycles;
	}
	
	public void set_mult_units(int fp_mult_Units) 	{
		mltiplier_units = fp_mult_Units;
	}
	
	public void set_fp_mult_Cycles(int fp_mult_Cycles) 	{
		multiplier_cycles = fp_mult_Cycles;
	}
	
	public int get_mult_Cycles() 	{
		return multiplier_cycles;
	}
	
	public int get_divide_Units() 	{
		return divider_units;
	}
	
	public int get_divider_Cycles() 	{
		return divider_cycles;
	}
	
	public void set_divider_Units(int fp_divider_Units) 	{
		divider_units = fp_divider_Units;
	}
	
	public void set_inst_cache_blocks(int inst_cache_num_blocks) 	{
		inst_cache_blocks = inst_cache_num_blocks;
	}
	
	public void set_divider_Cycles(int fp_divide_Cycles) 	{
		divider_cycles = fp_divide_Cycles;
	}
	
	public void set_inst_cache_block(int inst_cache_block_size) 	{
		inst_cache_size = inst_cache_block_size;
	}
	
	public int get_inst_cache_num_blocks() 	{
		return inst_cache_blocks;
	}
	
	public int get_inst_cache_block_size() 	{
		return inst_cache_size;
	}
	
}