package controllers;

public class clock_cycles {

	private long clock;
	
	public long count(){
		return this.clock;
	}
	
	public void increments(){
		this.clock++;
	}
	
	public clock_cycles(){
		this.clock = 1;
	}
	
}
