package units;

public enum inst_type
{

    HALT,
    J,
    ConditionalBranch,
    narth,
    LSW,
    LSD,
    fda,
    FMUL,
    FDIV,
    UNKNOWN;

}