package units;

import java.util.HashMap;
import java.util.Map;

public class funct_reg
{

    Map < String, Float > fpRegisters;

    public funct_reg()
    {
        this.fpRegisters = new HashMap < String, Float > ();
    }

    public void writeTo(String register, Float value)
    {
        this.fpRegisters.put(register, value);
    }

    public Float readFrom(String register)
    {
        if (register != null && this.fpRegisters.containsKey(register))
            return this.fpRegisters.get(register);
       
        else
            return null;
    }
}