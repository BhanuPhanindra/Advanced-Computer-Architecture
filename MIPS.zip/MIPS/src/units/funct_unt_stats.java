package units;

public class funct_unt_stats
{

    private boolean issource1Ready;
    private boolean issource2Ready;
    private functional_unit fType;
    private String sourceReg1;
    private String sourceReg2;
    private String destReg;
    private boolean status;

    public funct_unt_stats(functional_unit ftype)
    {
        this.fType = ftype;
        this.clear();
    }

    public void clear()
    {
        this.issource1Ready = false;
        this.issource2Ready = false;
        this.sourceReg1 = "";
        this.sourceReg2 = "";
        this.status = false;
        this.destReg = "";
    }

    public functional_unit getfType()
    {
        return fType;
    }
    public boolean isFtype(functional_unit fu)
    {
        return this.fType.ordinal() == fu.ordinal();
    }

    public boolean isSourceReg1(String reg)
    {
        return reg != null ? reg.equals(this.sourceReg1) : false;
    }

    public boolean isSourceReg2(String reg)
    {
        return reg != null ? reg.equals(this.sourceReg2) : false;
    }

    public boolean isDestReg(String reg)
    {
        return reg != null ? reg.equals(this.destReg) : false;
    }

    public boolean isStatus()
    {
        return status;
    }

    public boolean isSource1Ready()
    {
        return issource1Ready;
    }

    public boolean isSource2Ready()
    {
        return issource2Ready;
    }

    public void setfType(functional_unit fType)
    {
        this.fType = fType;
    }

    public void setSourceReg1(String sourceReg1)
    {
        this.sourceReg1 = sourceReg1;
    }

    public void setSourceReg2(String sourceReg2)
    {
        this.sourceReg2 = sourceReg2;
    }

    public void setDestReg(String destReg)
    {
        this.destReg = destReg;
    }

    public void setStatus(boolean status)
    {
        this.status = status;
    }

    public void setIssource1Ready(boolean issource1Ready)
    {
        this.issource1Ready = issource1Ready;
    }

    public void setIssource2Ready(boolean issource2Ready)
    {
        this.issource2Ready = issource2Ready;
    }

}