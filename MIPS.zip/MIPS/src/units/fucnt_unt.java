package units;

import instructions.abstrct.data_instr;
import instructions.impl.src_val;

import java.util.ArrayList;
import java.util.List;

public class fucnt_unt
{

    private List < funct_unt_stats > fp;
    private int fpMultiplier_Units;
    private int fpDivider_Units;
    private int fpAdder_Units;

    public fucnt_unt(int multipliers, int dividers, int adders)
    {

        fp = new ArrayList < funct_unt_stats > ();
        this.fpAdder_Units = adders;
        this.fpDivider_Units = dividers;
        this.fpMultiplier_Units = multipliers;
        for (int i = 0; i < this.fpMultiplier_Units; i++)
            fp.add(new funct_unt_stats(functional_unit.func_multr));
        
        for (int i = 0; i < this.fpAdder_Units; i++)
            fp.add(new funct_unt_stats(functional_unit.FPAdder));
        
        for (int i = 0; i < this.fpDivider_Units; i++)
            fp.add(new funct_unt_stats(functional_unit.FPDivider));
        
        fp.add(new funct_unt_stats(functional_unit.nier));
        fp.add(new funct_unt_stats(functional_unit.Ldunt));
        fp.add(new funct_unt_stats(functional_unit.BRANCH));
    }

    public boolean isAvailable(functional_unit fType)
    {
        for (int i = 0; i < fp.size(); i++)
        {
            if (fp.get(i).getfType() == fType && fp.get(i).isStatus() == false)
            {
                return true;
            }
        }
        return false;
    }


    public boolean isWAWHazard(String register)
    {
        for (int i = 0; i < fp.size(); i++)
        {
            if (fp.get(i).isStatus() == true && fp.get(i).isDestReg(register))
            {
                return true;
            }
        }
        return false;
    }

    public boolean isRAWHazardPresent(data_instr inst)
    {
        funct_unt_stats fStatus = inst.funct_stat;
        if (fStatus.isSource1Ready() == true && fStatus.isSource2Ready() == true)
        {
            return false;
        }
        return true;
    }

    public boolean isWARHazardPresent(data_instr inst)
    {
        if (inst.gt_dest_reg() == null)
            return false;

        String destReg = inst.gt_dest_reg().get_dest_loc();

        for (int i = 0; i < fp.size(); i++)
        {
            funct_unt_stats fStatus = inst.funct_stat;
            if (fStatus.isStatus())
            {
                if (fStatus.isSourceReg1(destReg) && fStatus.isSource1Ready())
                {
                    return true;
                }
                if (fStatus.isSourceReg2(destReg) && fStatus.isSource2Ready())
                {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isReady(String register)
    {
        for (int i = 0; i < fp.size(); i++)
        {
            funct_unt_stats fStatus = fp.get(i);
            if (fStatus.isStatus() == true && fStatus.isDestReg(register))
            {
                return false;
            }
        }
        return true;
    }

    public funct_unt_stats getFunctionalUnit(data_instr ist)
    {

        String destRegister = "";
        String srcRegister1 = "";
        String srcRegister2 = "";
        boolean src1Ready = true;
        boolean src2Ready = true;
        if (ist.gt_dest_reg() != null)
        {
            destRegister = ist.gt_dest_reg().get_dest_loc();
        }
        List < src_val > srcReg = ist.obt_src_reg();
        if (srcReg != null && srcReg.size() > 0)
        {
            srcRegister1 = ist.obt_src_reg().get(0).get_src();
            src1Ready = isReady(srcRegister1);
        }
        if (srcReg != null && srcReg.size() > 1)
        {
            srcRegister2 = ist.obt_src_reg().get(1).get_src();
            src2Ready = isReady(srcRegister2);
        }
        for (int i = 0; i < fp.size(); i++)
        {

            final funct_unt_stats status = fp.get(i);

            if (status != null && status.isStatus() == false && status.isFtype(ist.func_unit))
            {
                status.setfType(ist.func_unit);
                status.setIssource1Ready(src1Ready);
                status.setIssource2Ready(src2Ready);
                status.setSourceReg1(srcRegister1);
                status.setSourceReg2(srcRegister2);
                status.setDestReg(destRegister);
                status.setStatus(true);
                return status;
            }
        }
        return null;
    }

    public void writeToFunctionalStatus(data_instr inst)
    {

        funct_unt_stats fStatus = inst.funct_stat;

        if (inst.gt_dest_reg() == null)
        {
            fStatus.clear();
            return;
        }

        String destRegister = inst.gt_dest_reg().get_dest_loc();

        for (int i = 0; i < fp.size(); i++)
        {
            funct_unt_stats myStatus = fp.get(i);
            if (myStatus.isSourceReg1(destRegister))
            {
                myStatus.setIssource1Ready(true);
            }
            if (myStatus.isSourceReg2(destRegister))
            {
                myStatus.setIssource2Ready(true);
            }
        }

        fStatus.clear();

    } //end of method

}