package units;

import java.util.HashMap;
import java.util.Map;

public class int_regs
{

    Map < String, Integer > registers;

    public int_regs()
    {
        this.registers = new HashMap < String, Integer > (32);

        for (int i = 0; i < 32; i++)
            this.registers.put("F" + i, 0);
    }

    public void writeTo(String register, Integer value)
    {
        this.registers.put(register, value);
    }

    public Integer readFrom(String register)
    {
        if (this.registers.containsKey(register))
        {
            return this.registers.get(register);
        }
        else
            return null;
    }

}