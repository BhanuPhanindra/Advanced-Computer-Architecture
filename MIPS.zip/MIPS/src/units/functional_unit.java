package units;

public enum functional_unit 
{
		
	FPAdder,
	func_multr,
	FPDivider,
	Ldunt,
	nier,
	UNKNOWN,
	BRANCH;
}
