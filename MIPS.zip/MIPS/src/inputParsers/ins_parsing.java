	package inputParsers;

import instructions.abstrct.data_instr;
import instructions.impl.br_not_eq;
import instructions.impl.dadd;
import instructions.impl.data_add_imm;
import instructions.impl.div_data;
import instructions.impl.data_sub;
import instructions.impl.data_sub_imm;
import instructions.impl.halt;
import instructions.impl.jump;
import instructions.impl.load;
import instructions.impl.load_inst;
import instructions.impl.load_unt_inst;
import instructions.impl.load_word;
import instructions.impl.mult_data;
import instructions.impl.or_data;
import instructions.impl.or_imm;
import instructions.impl.store_data;
import instructions.impl.subtr_data;
import instructions.impl.store_word;
import instructions.impl.add_d;
import instructions.impl.and;
import instructions.impl.and_i;
import instructions.impl.br_eq;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import runme.Run;
import controllers.Run_mgr;

public class ins_parsing	{
	
	private static ins_parsing inst_parser= null;

	private ins_parsing() {}
	
	public static ins_parsing getInstance() 		{
		if(inst_parser== null)
			inst_parser = new ins_parsing();
		
		return inst_parser;
	}

	
	public synchronized void read_inst_file() throws IOException 	{

		File file_loc = new File( Run.getInstructionFile() );

		if( file_loc.exists() )		{
			
			try (BufferedReader buff_reader = new BufferedReader(new FileReader(file_loc));)		{
				String data_line = null;
				
				while ((data_line= buff_reader.readLine()) != null) 	{			    	
					if(!data_line.trim().isEmpty())
						get_data_from(data_line);
				}
				
			}catch(Exception exe)	{
				System.err.println("Error during readInstFile"+exe.getMessage());
			}
			
		}else	{
			System.err.println("File not found : "+ file_loc.getAbsolutePath() );
		}
		
	}

	public static data_instr getInstructionObj(String line) 
	{
		data_instr instruction = null;
		String[] labelNInst = line.trim().split(":");
		String label = "";
		String inst = "";
		String opcode = "";
		String destReg = "";
		String sourcereg1 ="";
		String sourcereg2 = "";
		String immediateVal = "";
		
		if(labelNInst.length==2)
		{
			label = labelNInst[0].trim();
			inst = labelNInst[1].trim();
			//RunManager.getInstance().addLabelToMap(label,RunManager.getInstance().getInstructionCount());
		}
		else
			inst = labelNInst[0].trim();
		
		String[] instparamArr = inst.trim().split(",|\\(|\\)|\\s+");
		List<String> instuction_list = new ArrayList<String>(Arrays.asList(instparamArr));
		instuction_list.removeAll(Collections.singleton(null));
		instuction_list.removeAll(Collections.singleton(""));

		if(instuction_list.size()>=1)
		{
			opcode = instuction_list.get(0).trim().toUpperCase();
			switch(opcode)
			{
			case "ADD.D":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new add_d(destReg, sourcereg1, sourcereg2);
				break;
			
			case "SUB.D":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new subtr_data(destReg, sourcereg1, sourcereg2);
				break;
			
			case "MUL.D":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new mult_data(destReg, sourcereg1, sourcereg2);
				break;
			
			case "DIV.D":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new div_data(destReg, sourcereg1, sourcereg2);
				break;
			
			case "DADD":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new dadd(destReg, sourcereg1, sourcereg2);
				break;
			
			case "DSUB":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new data_sub(destReg, sourcereg1, sourcereg2);
				break;
			
			case "AND":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new and(destReg, sourcereg1, sourcereg2);
				break;
			
			case "OR":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new or_data(destReg, sourcereg1, sourcereg2);
				break;
			
			case "DADDI":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				immediateVal = instuction_list.get(3).trim().toUpperCase();
				instruction = new data_add_imm(destReg, sourcereg1, immediateVal);
				break;
			
			case "DSUBI":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				immediateVal = instuction_list.get(3).trim().toUpperCase();
				instruction = new data_sub_imm(destReg, sourcereg1, immediateVal);
				break;
			
			case "ANDI":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				immediateVal = instuction_list.get(3).trim().toUpperCase();
				instruction = new and_i(destReg, sourcereg1, immediateVal);
				break;
			
			case "ORI":
				destReg = instuction_list.get(1).trim().toUpperCase();
				sourcereg1 = instuction_list.get(2).trim().toUpperCase();
				immediateVal = instuction_list.get(3).trim().toUpperCase();
				instruction = new or_imm(destReg, sourcereg1, immediateVal);
				break;
			
			case "LW":
				destReg = instuction_list.get(1).trim().toUpperCase();
				immediateVal = instuction_list.get(2).trim().toUpperCase();
				sourcereg1 = instuction_list.get(3).trim().toUpperCase();
				instruction = new load_word(destReg, sourcereg1, immediateVal);
				break;
			
			case "L.D":
				destReg = instuction_list.get(1).trim().toUpperCase();
				immediateVal = instuction_list.get(2).trim().toUpperCase();
				sourcereg1 = instuction_list.get(3).trim().toUpperCase();
				instruction = new load(destReg, sourcereg1, immediateVal);
				break;
			
			case "SW":
				sourcereg1 = instuction_list.get(1).trim().toUpperCase();
				immediateVal = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new store_word(sourcereg1, sourcereg2, immediateVal);
				break;
			
			case "S.D":
				sourcereg1 = instuction_list.get(1).trim().toUpperCase();
				immediateVal = instuction_list.get(2).trim().toUpperCase();
				sourcereg2 = instuction_list.get(3).trim().toUpperCase();
				instruction = new store_data(sourcereg1, sourcereg2, immediateVal);
				break;
			
			case "LI":
				destReg = instuction_list.get(1).trim().toUpperCase();
				immediateVal = instuction_list.get(2).trim().toUpperCase();
				instruction = new load_inst(destReg, immediateVal);
				break;
			
			case "LUI":
				destReg = instuction_list.get(1).trim().toUpperCase();
				immediateVal = instuction_list.get(2).trim().toUpperCase();
				instruction = new load_unt_inst(destReg, immediateVal);
				break;
			
			case "BNE":
				sourcereg1 = instuction_list.get(1).trim().toUpperCase();
				sourcereg2 = instuction_list.get(2).trim().toUpperCase();
				destReg = instuction_list.get(3).trim().toUpperCase();
				instruction = new br_not_eq(sourcereg1, sourcereg2, destReg);
				break;
			
			case "BEQ":
				sourcereg1 = instuction_list.get(1).trim().toUpperCase();
				sourcereg2 = instuction_list.get(2).trim().toUpperCase();
				destReg = instuction_list.get(3).trim().toUpperCase();
				instruction = new br_eq(sourcereg1, sourcereg2, destReg);
				break;
			
			case "J":
				destReg = instuction_list.get(1).trim().toUpperCase();
				instruction = new jump(destReg);
				break;
			
			case "HLT":
				instruction = new halt();
				break;
			}
			
			instruction.set_instr(instruction.toString());
			instruction.set_label(label);
			return instruction;
		}
		return null;
	}
	
	private void get_data_from(String line_str) throws Exception 
	{
		data_instr instr = null;
		String[] label_inst = line_str.trim().split(":");
		String lab = "";
		String inst = "";
		String opc = "";
		String fin_reg = "";
		String init_reg1 ="";
		String init_reg2 = "";
		String imm_val = "";
		Run_mgr run_mgr = Run_mgr.get_inst();

		if(label_inst.length==2)
		{
			inst = label_inst[1].trim();
			lab = label_inst[0].trim();
			Run_mgr.get_inst().add_label_map(lab,Run_mgr.get_inst().get_inst_count());
		}
		else
			inst = label_inst[0].trim();
		
		String[] instruction_arr = inst.trim().split(",|\\(|\\)|\\s+");
		List<String> instruction_list = new ArrayList<String>(Arrays.asList(instruction_arr));
		instruction_list.removeAll(Collections.singleton(null));
		instruction_list.removeAll(Collections.singleton(""));

		if(instruction_list.size()>=1)
		{
			opc = instruction_list.get(0).trim().toUpperCase();
			switch(opc)
			{
			case "ADD.D":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new add_d(fin_reg, init_reg1, init_reg2);
				break;
			
			case "SUB.D":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new subtr_data(fin_reg, init_reg1, init_reg2);
				break;
			
			case "MUL.D":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new mult_data(fin_reg, init_reg1, init_reg2);
				break;
			
			case "DIV.D":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new div_data(fin_reg, init_reg1, init_reg2);
				break;
			
			case "DADD":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new dadd(fin_reg, init_reg1, init_reg2);
				break;
			
			case "DSUB":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new data_sub(fin_reg, init_reg1, init_reg2);
				break;
			
			case "AND":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new and(fin_reg, init_reg1, init_reg2);
				break;
			
			case "OR":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new or_data(fin_reg, init_reg1, init_reg2);
				break;
			
			case "DADDI":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				imm_val = instruction_list.get(3).trim().toUpperCase();
				instr = new data_add_imm(fin_reg, init_reg1, imm_val);
				break;
			
			case "DSUBI":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				imm_val = instruction_list.get(3).trim().toUpperCase();
				instr = new data_sub_imm(fin_reg, init_reg1, imm_val);
				break;
			
			case "ANDI":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				imm_val = instruction_list.get(3).trim().toUpperCase();
				instr = new and_i(fin_reg, init_reg1, imm_val);
				break;
			
			case "ORI":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				init_reg1 = instruction_list.get(2).trim().toUpperCase();
				imm_val = instruction_list.get(3).trim().toUpperCase();
				instr = new or_imm(fin_reg, init_reg1, imm_val);
				break;
			
			case "LW":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				imm_val = instruction_list.get(2).trim().toUpperCase();
				init_reg1 = instruction_list.get(3).trim().toUpperCase();
				instr = new load_word(fin_reg, init_reg1, imm_val);
				break;
			
			case "L.D":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				imm_val = instruction_list.get(2).trim().toUpperCase();
				init_reg1 = instruction_list.get(3).trim().toUpperCase();
				instr = new load(fin_reg, init_reg1, imm_val);
				break;
			
			case "SW":
				init_reg1 = instruction_list.get(1).trim().toUpperCase();
				imm_val = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new store_word(init_reg1, init_reg2, imm_val);
				break;
			
			case "S.D":
				init_reg1 = instruction_list.get(1).trim().toUpperCase();
				imm_val = instruction_list.get(2).trim().toUpperCase();
				init_reg2 = instruction_list.get(3).trim().toUpperCase();
				instr = new store_data(init_reg1, init_reg2, imm_val);
				break;
			
			case "LI":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				imm_val = instruction_list.get(2).trim().toUpperCase();
				instr = new load_inst(fin_reg, imm_val);
				break;
			
			case "LUI":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				imm_val = instruction_list.get(2).trim().toUpperCase();
				instr = new load_unt_inst(fin_reg, imm_val);
				break;
			
			case "BNE":
				init_reg1 = instruction_list.get(1).trim().toUpperCase();
				init_reg2 = instruction_list.get(2).trim().toUpperCase();
				fin_reg = instruction_list.get(3).trim().toUpperCase();
				instr = new br_not_eq(init_reg1, init_reg2, fin_reg);
				break;
			
			case "BEQ":
				init_reg1 = instruction_list.get(1).trim().toUpperCase();
				init_reg2 = instruction_list.get(2).trim().toUpperCase();
				fin_reg = instruction_list.get(3).trim().toUpperCase();
				instr = new br_eq(init_reg1, init_reg2, fin_reg);
				break;
			
			case "J":
				fin_reg = instruction_list.get(1).trim().toUpperCase();
				instr = new jump(fin_reg);
				break;
			
			case "HLT":
				instr = new halt();
				break;
			
			default:
				System.out.println("Exception in Line : "+(run_mgr.get_inst_count()+1)+" "+line_str);
				throw new Exception();
			}
			
			instr.set_instr(instr.toString());
			instr.set_label(lab);
			run_mgr.add_instr(run_mgr.get_inst_count(), line_str);
		}
	}
}
