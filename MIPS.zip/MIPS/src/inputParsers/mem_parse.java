package inputParsers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import runme.Run;

public class mem_parse 
{
	private static mem_parse memory_parser = null;
	private long inital_Address;
	
	private List<String []> info;
	
	private mem_parse()	{
		this.info = new ArrayList<String[]>();
		this.inital_Address = 256;
	}
	
	public static mem_parse getInstance()		{
		if(memory_parser == null)	{
			memory_parser = new mem_parse();
		}
		return memory_parser;
	}
	
	public String[] getdataArr(long add)
	{
		int ind = (int)(add - inital_Address)/4;
		ind = ind/4;
		return info.get(ind);
	}

	public String[] updateNReturnData(long add, int offset, String data)
	{
		int ind = (int)(add - inital_Address)/4;
		ind = ind / 4;
		String[] data_arr = this.info.get(ind);
		data_arr[offset] = data;
		return data_arr;
	}

	
	public synchronized void reading_config()		{
		
		File fileloc = new File(Run.getDataFile());
		
		if( fileloc.exists() )		{
			try( BufferedReader buff_read = new BufferedReader(new FileReader(fileloc)); )	{
				
				String[] block_data  = new String[4];
				String line_read;
				int ind = 0;
				
				while ((line_read = buff_read.readLine()) != null) 	{
					if((ind+1)%4 == 0)
					{
						block_data[ind%4] = line_read;
						info.add(block_data);
						block_data = new String[4];
					}
					block_data[ind%4] = line_read;
					ind++;
				}
			}catch(Exception exe)	{
				exe.printStackTrace();
			}
		}else	{
			System.err.println("File not found : "+ fileloc.getAbsolutePath() );
		}

	}

	public void pushMemDataToFile()
	{
		StringBuilder sb = new StringBuilder("");
		for(int i=0; i<info.size();i++)		{
			for(int j=0; j<info.get(i).length;j++)
				sb.append(info.get(i)[j]).append(System.lineSeparator());

		}
		result_write.getInstance().writeToFile(sb.toString());
	}
	
	public void updateData(long add, String[] obt_data)
	{
		int index = (int)(add-inital_Address)/4;
		index = index/4;
		String newData[] = new String[4];
		
		for(int i =0; i < obt_data.length; i++)
			newData[i] = obt_data[i];
		
		info.set(index, newData);
		
	}
	
}