package inputParsers;

import java.io.*;

import runme.Run;

public class result_write 	{
	
	private static result_write Writer = null;
	
	private result_write() {}
	
	public synchronized void writeToFile(String data)	{
		
		File file_ptr = new File(Run.getResuleFile());
		
		if( file_ptr.exists() )		{
			
			try (BufferedWriter buff_writer = new BufferedWriter(new FileWriter(file_ptr));)	{
				
				buff_writer.write(data.trim());
				
			}catch (IOException e)  {
				System.err.println("Error during output writing"+e.getLocalizedMessage());
			}
			
		}else	{
			System.err.println(" File not found : "+ file_ptr.getAbsolutePath() );
		}
		
		
	}
	
	public static result_write getInstance() 	{
		if(Writer== null)
			Writer = new result_write();
		return Writer;
	}
	
}
