package inputParsers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import runme.Run;
import controllers.configuration_management;

public class config_str 
{
	private static config_str configparser= null;
	
	private config_str() {}
	
	public static config_str getInstance() 	{
		if(configparser== null)
			configparser = new config_str();
		return configparser;
	}
	
	private void updateConfigInfo(String line) 		{
		
		configuration_management config_mgr = configuration_management.getInstance();
		String[] line_array = line.split(",|:");
		
		if(line_array.length==3)
		{
			String keys = line_array[0].trim();
			String no_units = line_array[1].trim();
			String no_cycles = line_array[2].trim();
			
			switch(keys.toUpperCase().trim())
			{
				case "FP ADDER":
					config_mgr.set_add_units(Integer.parseInt(no_units));
					config_mgr.set_add_cycles(Integer.parseInt(no_cycles));
					break;
				
				case "FP MULTIPLIER":
					config_mgr.set_mult_units(Integer.parseInt(no_units));
					config_mgr.set_fp_mult_Cycles(Integer.parseInt(no_cycles));
					break;
				
				case "FP DIVIDER":
					config_mgr.set_divider_Units(Integer.parseInt(no_units));
					config_mgr.set_divider_Cycles(Integer.parseInt(no_cycles));
					break;
				
				case "I-CACHE":
					config_mgr.set_inst_cache_blocks(Integer.parseInt(no_units));
					config_mgr.set_inst_cache_block(Integer.parseInt(no_cycles));
					break;
			}
		}else	{
			System.err.println(" updateConfigInfo():  Invalid Link format ");
		}
		
	}
	
	public synchronized void read_config_file() throws IOException 	{
		
		File fileloc = new File (Run.getConfigFile());
		
		if( fileloc.exists() )	{
			
			try ( BufferedReader buffer_read = new BufferedReader(new FileReader(fileloc));) 
			{
				String read_line = null;
				
			    while ((read_line= buffer_read.readLine()) != null) 	{			    	
			        if(!read_line.trim().isEmpty())
			        	updateConfigInfo(read_line);
			    }
			    
			}catch(Exception exe)	{
				System.err.println("Error during reading of ConfigFile"+exe.getMessage());
			}
			
		}else	{
			System.err.println(" File not found : "+ fileloc.getAbsolutePath() );
		}
		
	}	
}
