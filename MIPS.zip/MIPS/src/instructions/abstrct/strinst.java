package instructions.abstrct;

import instructions.impl.src_val;
import instructions.impl.dest_val;

import java.util.ArrayList;
import java.util.List;

public abstract class strinst extends data_instr	{
	
	protected src_val source1;
	protected src_val source2;
	protected int imm;
	
	public strinst(String s1, String s2, String imm)	{
		this.imm = Integer.parseInt(imm);
		this.source1 = new src_val(s1, 0);
		this.source2 = new src_val(s2, 0);
	}
	
	@Override
	public dest_val gt_dest_reg() {
		return null;
	}
	
	@Override
	public List<src_val> obt_src_reg() {
		List<src_val> sourcelist = new ArrayList<src_val>();
		sourcelist.add(this.source1);
		sourcelist.add(this.source2);
		return sourcelist;
	}

	

}
