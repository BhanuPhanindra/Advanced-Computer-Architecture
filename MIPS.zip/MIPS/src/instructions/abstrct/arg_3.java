package instructions.abstrct;

import instructions.impl.src_val;
import instructions.impl.dest_val;

import java.util.*;

public abstract class arg_3 extends data_instr		{
	
	protected src_val src1 = null;
	protected src_val src2 = null;
	protected dest_val dest = null;
	
	public arg_3 (String d, String s1, String s2)	{
		this.src1 = new src_val(s1,0);
		this.src2 = new src_val(s2,0);
		this.dest = new dest_val(d,0);
	}
	
	
	@Override
	public List<src_val> obt_src_reg() 	{
		List<src_val> sourcelist = new ArrayList<src_val>();
		sourcelist.add(this.src1);
		sourcelist.add(this.src2);
		return sourcelist;
	}

	@Override
	public dest_val gt_dest_reg() 	{
		return this.dest;	
	}
	
}
