package instructions.abstrct;

import instructions.impl.src_val;
import instructions.impl.dest_val;

import java.util.ArrayList;
import java.util.List;

public abstract class arg3_imm extends data_instr		{
	
	protected src_val src1 = null;
	protected int imme ;
	protected dest_val dest = null;
	
	public arg3_imm(String d, String s1, String imm) 	{
		this.dest = new dest_val(d, 0);
		this.src1 = new src_val(s1, 0);
		this.imme = Integer.parseInt(imm);
	}
	
	@Override
	public dest_val gt_dest_reg() 	{
		return this.dest;
	}

	@Override
	public List<src_val> obt_src_reg() 		{
		List<src_val> src_lst = new ArrayList<src_val>();
		src_lst.add(this.src1);
		return src_lst;
	}
	
}
