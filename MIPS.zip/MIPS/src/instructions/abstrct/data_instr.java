package instructions.abstrct;

import instructions.Inst;
import runme.program_mgr;
import units.funct_unt_stats;
import units.functional_unit;
import units.inst_type;

public abstract class data_instr implements Inst, Comparable<data_instr>		{
	
	public boolean Write_Aft_Read_ha;
	public boolean Write_Aft_Write_ha;
	public boolean Read_Aft_Write_ha;
	public funct_unt_stats funct_stat;
	public functional_unit func_unit;
	public boolean struct_hazard;
	public int instruct_issue;
	public inst_type instt;
	public int[] begin_cyc;
	public int[] last_cyc;
	public long address;
	
	private String inst_string = "";
	private String lab = "";
		
	public  data_instr()		{
		this.Read_Aft_Write_ha = false;
		this.Write_Aft_Read_ha = false;
		this.Write_Aft_Write_ha = false;
		this.struct_hazard = false;
		this.begin_cyc = new int[5];
		this.last_cyc = new int[5];
		this.func_unit = functional_unit.UNKNOWN;
		this.instt = inst_type.UNKNOWN;	
	}

	public void set_label(String lab) {
		this.lab = lab;
	}	
	public void set_instr(String instr)	{
		this.inst_string = instr;
	}
	
	public void setSource1Ready(boolean status) {
		this.funct_stat.setIssource1Ready(status);
	}
	public void setSource2Ready(boolean status) {
		this.funct_stat.setIssource2Ready(status);
	}
	
	public String get_output()		{
		
		Object[] test = new String[10];
		test[0] = this.lab;
		test[1] = this.inst_string;
		
		for(int ind=0; ind<this.last_cyc.length;ind++)	{
			if(this.last_cyc[ind]!=0)
				test[ind+2] = String.valueOf( this.last_cyc[ind] );
			else
				test[ind+2] = "";
		}
		
		if(this.Read_Aft_Write_ha)
			test[7] = "Y";
		else
			test[7] = "N";
		
		if(this.Write_Aft_Write_ha)
			test[8] = "Y";
		else
			test[8] = "N";
			
		if(this.struct_hazard)
			test[9] = "Y";
		else
			test[9] = "N";
		
		return String.format(program_mgr.output_syntax, test);
		
	}
	
	
	@Override
	public int compareTo(data_instr o)		{
		if(this.instruct_issue < o.instruct_issue)
			return -1;
		else
			return 1;
	}

}
