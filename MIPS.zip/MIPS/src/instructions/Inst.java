package instructions;

import instructions.impl.src_val;
import instructions.impl.dest_val;

import java.util.List;

public interface Inst {
	
	public void exec_inst();
	public dest_val gt_dest_reg();
	public List<src_val> obt_src_reg();

}
