package instructions.impl;

import instructions.abstrct.strinst;
import units.functional_unit;
import units.inst_type;

public class store_data extends strinst
{

    public store_data(String s1, String s2, String imm)
    {
        super(s1, s2, imm);
        this.instt = inst_type.LSD;
        this.func_unit = functional_unit.Ldunt;
    }

    @Override
    public void exec_inst()
    {
        this.address = this.imm + this.source2.get_val();
    }

    public src_val getValuetowriteToMemory()
    {
        return this.source1;
    }

    @Override
    public String toString()
    {
        return "SD " + source1.get_src() + ", " + imm + "(" + source2.get_src() + ")";
    }
}