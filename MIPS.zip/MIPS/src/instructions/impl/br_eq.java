package instructions.impl;

import instructions.abstrct.data_instr;

import java.util.*;

import units.*;

public class br_eq extends data_instr
{
    private src_val src1;
    private src_val src2;
    private String brn_to_lbl;

    public br_eq(String s1, String s2, String label)
    {
        this.brn_to_lbl = label;
        this.src1 = new src_val(s1, 0);
        this.src2 = new src_val(s2, 0);
        this.func_unit = functional_unit.BRANCH;
        this.instt = inst_type.ConditionalBranch;
    }

    public boolean obt_res()
    {
        return (src1.get_val() == src2.get_val());
    }

    public String getBranchToLabel()
    {
        return this.brn_to_lbl;
    }

    @Override
    public List < src_val > obt_src_reg()
    {
        List < src_val > srclst = new ArrayList < src_val > ();
        srclst.add(this.src1);
        srclst.add(this.src2);
        return srclst;
    }

    @Override
    public dest_val gt_dest_reg()
    {
        return null;
    }

    @Override
    public void exec_inst()
    {}

    @Override
    public String toString()
    {
        return "BEQ " + " " + src1.get_src() + ", " + src2.get_src() + ", " + this.brn_to_lbl;
    }

}