package instructions.impl;

import instructions.abstrct.arg3_imm;
import units.functional_unit;
import units.inst_type;

public class load extends arg3_imm
{

    public load(String d, String s1, String imm)
    {
        super(d, s1, imm);
        this.instt = inst_type.LSD;
        this.func_unit = functional_unit.Ldunt;
    }

    @Override
    public void exec_inst()
    {
        this.address = src1.get_val() + this.imme;
    }

    @Override
    public String toString()
    {
        return "LD " + dest.get_dest_loc() + ", " + imme + "(" + src1.get_src() + ")";
    }

}