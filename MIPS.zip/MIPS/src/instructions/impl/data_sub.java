package instructions.impl;

import instructions.abstrct.arg_3;
import units.functional_unit;
import units.inst_type;

public class data_sub extends arg_3
{

    public data_sub(String d, String s1, String s2)
    {
        super(d, s1, s2);
        this.instt = inst_type.narth;
        this.func_unit = functional_unit.nier;
    }

    @Override
    public void exec_inst()
    {
        dest.set_val(src1.get_val() - src2.get_val());
    }

    @Override
    public String toString()
    {
        return "DSUB " + dest.get_dest_loc() + ", " + src1.get_src() + ", " + src2.get_src();
    }

}