package instructions.impl;

import instructions.abstrct.arg_3;
import units.*;

public class add_d extends arg_3
{
    @Override
    public String toString()
    {
        return "ADD.D " + dest.get_dest_loc() + ", " + src1.get_src() + ", " + src2.get_src();
    }

	@Override
	 public void exec_inst()
	    {
	        dest.set_val(src1.get_val() + src2.get_val());
	    }
	
	public add_d(String dest, String src1, String src2)
    {
        super(dest, src1, src2);
        this.func_unit = functional_unit.FPAdder;
        this.instt = inst_type.fda;
    }

}