package instructions.impl;

public class dest_val
{

    private String dest;
    private int val;

    public dest_val(String des, int val)
    {
        this.dest = des != null ? des.trim() : "";
        this.val = val;
    }

    public String get_dest_loc()
    {
        return dest;
    }
    public void setDestination(String destination)
    {
        this.dest = destination;
    }
    public int getValue()
    {
        return val;
    }
    public void set_val(int value)
    {
        this.val = value;
    }

}