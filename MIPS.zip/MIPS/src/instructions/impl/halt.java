package instructions.impl;

import instructions.abstrct.data_instr;

import java.util.List;

import units.functional_unit;
import units.inst_type;

public class halt extends data_instr
{

    public halt()
    {
        this.instt = inst_type.HALT;
        this.func_unit = functional_unit.UNKNOWN;
    }

    @Override
    public void exec_inst()
    {}

    @Override
    public dest_val gt_dest_reg()
    {
        return null;
    }

    @Override
    public List < src_val > obt_src_reg()
    {
        return null;
    }

    @Override
    public String toString()
    {
        return "HLT";
    }
}