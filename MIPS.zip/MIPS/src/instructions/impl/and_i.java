package instructions.impl;

import instructions.abstrct.arg3_imm;
import units.*;

public class and_i extends arg3_imm
{

    public and_i(String d, String s1, String imm)
    {
        super(d, s1, imm);
        this.instt = inst_type.narth;
        this.func_unit = functional_unit.nier;
    }

    @Override
    public void exec_inst()
    {
        dest.set_val(src1.get_val() & imme);
    }

    @Override
    public String toString()
    {
        return "ANDI " + dest.get_dest_loc() + ", " + src1.get_src() + "," + imme;
    }

}