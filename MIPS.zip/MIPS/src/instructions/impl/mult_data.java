package instructions.impl;

import instructions.abstrct.arg_3;
import units.functional_unit;
import units.inst_type;

public class mult_data extends arg_3
{

    public mult_data(String d, String s1, String s2)
    {
        super(d, s1, s2);
        this.instt = inst_type.FMUL;
        this.func_unit = functional_unit.func_multr;
    }

    @Override
    public void exec_inst()
    {
        dest.set_val(src1.get_val() * src2.get_val());
    }

    @Override
    public String toString()
    {
        return "MUL.D " + dest.get_dest_loc() + ", " + src1.get_src() + ", " + src2.get_src();
    }

}