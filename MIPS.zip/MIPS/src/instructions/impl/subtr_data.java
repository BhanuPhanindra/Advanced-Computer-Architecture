package instructions.impl;

import instructions.abstrct.arg_3;
import units.functional_unit;
import units.inst_type;

public class subtr_data extends arg_3
{

    public subtr_data(String des, String source1, String source2)
    {
        super(des, source1, source2);
        this.func_unit = functional_unit.FPAdder;
        this.instt = inst_type.fda;
    }

    @Override
    public void exec_inst()
    {
        dest.set_val(src1.get_val() - src2.get_val());
    }

    @Override
    public String toString()
    {
        return "SUB.D " + dest.get_dest_loc() + "," + src1.get_src() + "," + src2.get_src();
    }

}