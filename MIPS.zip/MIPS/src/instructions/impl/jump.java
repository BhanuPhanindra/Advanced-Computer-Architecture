package instructions.impl;

import instructions.abstrct.data_instr;

import java.util.List;

public class jump extends data_instr
{

    private String jum;

    public jump(String destLabel)
    {
        this.jum = destLabel;
    }

    public String gt_jp_to()
    {
        return this.jum;
    }

    @Override
    public void exec_inst()
    {}

    @Override
    public dest_val gt_dest_reg()
    {
        return null;
    }

    @Override
    public List < src_val > obt_src_reg()
    {
        return null;
    }

    @Override
    public String toString()
    {
        return "J " + this.jum;
    }

}