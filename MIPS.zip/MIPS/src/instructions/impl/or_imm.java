package instructions.impl;

import instructions.abstrct.arg3_imm;
import units.functional_unit;
import units.inst_type;

public class or_imm extends arg3_imm
{

    public or_imm(String d, String s1, String imm)
    {
        super(d, s1, imm);
        this.instt = inst_type.narth;
        this.func_unit = functional_unit.nier;
    }

    @Override
    public void exec_inst()
    {
        dest.set_val(src1.get_val() | imme);
    }

    @Override
    public String toString()
    {
        return "ORI " + dest.get_dest_loc() + ", " + src1.get_src() + "," + this.imme;
    }
}