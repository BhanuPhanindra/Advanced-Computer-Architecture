package instructions.impl;

import instructions.abstrct.arg3_imm;
import units.functional_unit;
import units.inst_type;

public class load_word extends arg3_imm
{

    public load_word(String d, String s1, String imm)
    {
        super(d, s1, imm);
        this.instt = inst_type.LSW;
        this.func_unit = functional_unit.Ldunt;
    }

    @Override
    public void exec_inst()
    {
        this.address = imme + src1.get_val();
    }

    @Override
    public String toString()
    {
        return "LW " + dest.get_dest_loc() + ", " + imme + "(" + src1.get_src() + ")";
    }
}