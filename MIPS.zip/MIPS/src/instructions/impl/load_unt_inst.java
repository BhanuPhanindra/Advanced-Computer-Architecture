package instructions.impl;

import instructions.abstrct.data_instr;

import java.util.List;

import units.functional_unit;

public class load_unt_inst extends data_instr
{

    private final int pow = 65536; // Math.pow(2,16)
    private dest_val dest;
    private int immd;

    public load_unt_inst(String dest, String imm)
    {
        this.dest = new dest_val(dest, 0);
        this.immd = Integer.parseInt(imm);
        this.func_unit = functional_unit.nier;
    }

    @Override
    public void exec_inst()
    {
        this.dest.set_val(pow * this.immd);
    }

    @Override
    public dest_val gt_dest_reg()
    {
        return this.dest;
    }

    @Override
    public List < src_val > obt_src_reg()
    {
        return null;
    }

    @Override
    public String toString()
    {
        return "LUI " + this.dest.get_dest_loc() + ", " + this.immd;
    }

}