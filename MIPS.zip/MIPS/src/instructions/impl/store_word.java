package instructions.impl;

import instructions.abstrct.strinst;
import units.functional_unit;
import units.inst_type;

public class store_word extends strinst
{

    public store_word(String s1, String s2, String imm)
    {
        super(s1, s2, imm);
        this.instt = inst_type.LSW;
        this.func_unit = functional_unit.Ldunt;
    }

    @Override
    public void exec_inst()
    {
        this.address = this.imm + this.source2.get_val();
    }

    public src_val getValuetowriteToMemory()
    {
        return this.source1;
    }

    @Override
    public String toString()
    {
        return "SW " + source1.get_src() + ", " + imm + "(" + source2.get_src() + ")";
    }
}