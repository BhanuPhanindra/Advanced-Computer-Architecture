package instructions.impl;

public class src_val
{

    private String Source = "";
    private int value = 0;

    public src_val(String s, int val)
    {
        this.Source = s;
        this.value = val;
    }

    public String get_src()
    {
        return Source;
    }
    public void st_src(String source)
    {
        Source = source;
    }
    public int get_val()
    {
        return value;
    }
    public void st_val(int value)
    {
        this.value = value;
    }



}