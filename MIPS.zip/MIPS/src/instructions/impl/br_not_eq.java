package instructions.impl;

import instructions.abstrct.data_instr;

import java.util.ArrayList;
import java.util.List;

import units.functional_unit;
import units.inst_type;

public class br_not_eq extends data_instr
{

    private src_val source1;
    private src_val source2;
    private String branchToLabel;

    public br_not_eq(String s1, String s2, String label)
    {
        this.branchToLabel = label;
        this.source1 = new src_val(s1, 0);
        this.source2 = new src_val(s2, 0);
        this.func_unit = functional_unit.BRANCH;
        this.instt = inst_type.ConditionalBranch;
    }

    public boolean getComparedResult()
    {
        return (source1.get_val() != source2.get_val());
    }

    public String getBranchToLabel()
    {
        return this.branchToLabel;
    }

    @Override
    public void exec_inst()
    {}

    @Override
    public dest_val gt_dest_reg()
    {
        return null;
    }

    @Override
    public List < src_val > obt_src_reg()
    {
        List < src_val > sourcelist = new ArrayList < src_val > ();
        sourcelist.add(this.source1);
        sourcelist.add(this.source2);
        return sourcelist;
    }

    @Override
    public String toString()
    {
        return "BNE  " + source1.get_src() + ", " + source2.get_src() + ", " + this.branchToLabel;
    }

}