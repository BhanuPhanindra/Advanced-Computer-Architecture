package runme;

import inputParsers.*;
import java.io.*;
import java.util.*;

public class Run
{

    private static Properties prop;

    public static String getConfigFile()
    {
        return Run.prop.getProperty("config.file.path").trim();
    }

    public static String getDataFile()
    {
        return Run.prop.getProperty("data.file.path").trim();
    }

    public static String getInstructionFile()
    {
        return Run.prop.getProperty("instructions.file.path").trim();
    }

    public static String getResuleFile()
    {
        return Run.prop.getProperty("result.file.path").trim();
    }


    public static void main(String[] args) throws Exception
    {

        try (InputStream is = Run.class.getClassLoader().getResourceAsStream("config.properties");)
        {

            Run.prop = new Properties();
            prop.load(is);

            config_str config_parser = config_str.getInstance();
            ins_parsing instr_parser = ins_parsing.getInstance();
            mem_parse mem_parser = mem_parse.getInstance();

            try
            {

                checkResources();
                config_parser.read_config_file();
                instr_parser.read_inst_file();
                mem_parser.reading_config();

                program_mgr prg_mgr = new program_mgr();
                prg_mgr.program_execution();

            }
            catch (IOException e)
            {
                System.err.println("ConfigParser: " + e.getMessage());
            }

            prop.clear();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    private static void checkResources()
    {

        Iterator < Object > iter = Run.prop.keySet().iterator();

        while (iter.hasNext())
        {
            String key = (String) iter.next();
            if (key.endsWith("file.path"))
                checkResource(prop.getProperty(key).trim());
        }

    }

    private static void checkResource(String filename)
    {

        try (InputStream is = Run.class.getClassLoader().getResourceAsStream(filename))
        {

            int bit = 0;

            String path = System.getProperty("user.dir");
            File tempFile = new File(path, "resource");
            tempFile.mkdirs();
            tempFile.setReadable(true, false);
            tempFile.setWritable(true, false);

            path += (File.separator + "resource" + File.separator);
            tempFile = new File(path, filename);

            if (tempFile.exists())
            {

                tempFile.createNewFile();

                FileOutputStream fos = new FileOutputStream(tempFile);
                BufferedOutputStream bos = new BufferedOutputStream(fos);
                do {
                    bit = is.read();
                    if (bit == -1)
                    {
                        break;
                    }
                    bos.write(bit);
                } while (bit != -1);

                is.close();
                bos.close();

            }

        }
        catch (Exception e)
        {
            System.err.println(" ERROR finding resource: " + filename + " : " + e.getMessage());
        } //End Of Try Catch

    } //End Of Method

}