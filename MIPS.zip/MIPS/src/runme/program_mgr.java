package runme;

import inputParsers.*;
import instructions.abstrct.data_instr;
import instructions.impl.*;

import java.util.*;

import memoryBlocks.*;
import units.*;
import controllers.*;

public class program_mgr
{

    public static final String output_syntax = " %-5s  %-25s  %-5s  %-5s  %-5s  %-5s  %-7s  %-7s  %-7s  %-7s ";
    private static final Object[] header_array = new Object[]
    {
        "Label",
        "Instruction",
        "Fetch",
        "Issue",
        "Read",
        "Exec",
        "Write",
        "RAW",
        "WAW",
        "Struct"
    };

    private configuration_management configMgr;
    private List < data_instr > reader;
    private List < data_instr > fetcher;
    private List < data_instr > issuer;
    private List < data_instr > writeBack;
    private List < data_instr > execute;
    private int_regs registers;
    private clock_cycles clock;
    private int write_back_ind;
    private fucnt_unt fu;
    private ICache iCache;
    private DCache dCache;
    private int execute_ind;
    private int read_ind;
    private int issue_ind;
    private int fetch_ind;
    private Run_mgr runMgr;
    private int pc;

    public program_mgr()
    {
        registers = new int_regs();
        clock = new clock_cycles();
        pc = 0;

        runMgr = Run_mgr.get_inst();
        configuration_management cm = this.configMgr = configuration_management.getInstance();
        initCache();

        fu = new fucnt_unt(cm.get_mult_units(), cm.get_divide_Units(), cm.get_add_Units());
        writeBack = new ArrayList < data_instr > ();
        execute = new ArrayList < data_instr > ();
        fetcher = new ArrayList < data_instr > ();
        issuer = new ArrayList < data_instr > ();
        reader = new ArrayList < data_instr > ();

        write_back_ind = 4;
        execute_ind = 3;
        read_ind = 2;
        issue_ind = 1;
        fetch_ind = 0;

    }

    private void initCache()
    {
        memry_bus bus = new memry_bus();
        iCache = new ICache(this.configMgr.get_inst_cache_num_blocks(), this.configMgr.get_inst_cache_block_size(), clock, bus);
        dCache = new DCache(clock, bus);
    }


    public void program_execution()
    {

        boolean completed;
        boolean stall = false;
        boolean flushing = false;
        int Instrcution_issue = 0;
        boolean to_stall = false;
        List < data_instr > fetch_Word = new ArrayList < data_instr > ();
        List < data_instr > instruction_completed = new ArrayList < data_instr > ();

        while (true)
        {
            completed = true;

            List < data_instr > branch = new ArrayList < data_instr > ();
            List < data_instr > elgible = new ArrayList < data_instr > ();
            List < data_instr > flushed = new ArrayList < data_instr > ();
            List < data_instr > haltBranch = new ArrayList < data_instr > ();

            if (writeBack.size() != 0)
            {
                completed = false;
                for (int i = 0; i < writeBack.size(); i++)
                {
                    data_instr inst = writeBack.get(i);
                    if (inst.last_cyc[this.write_back_ind] < clock.count())
                    {
                        if (inst.gt_dest_reg() != null && fu.isWARHazardPresent(inst))
                            inst.Write_Aft_Read_ha = true;
                        else
                            elgible.add(inst);
                    }
                }
            }

            if (execute.size() != 0)
            {
                completed = false;
                List < data_instr > writeElgible = new ArrayList < data_instr > ();
                for (int i = 0; i < execute.size(); i++)
                {
                    data_instr inst = execute.get(i);
                    if (inst.last_cyc[this.execute_ind] < clock.count())
                    {
                        writeElgible.add(inst);
                    }
                }
                for (int i = 0; i < writeElgible.size(); i++)
                {
                    data_instr inst = writeElgible.get(i);
                    execute.remove(inst);
                    inst.last_cyc[this.write_back_ind] = (int)(this.clock.count() + 1 - 1);
                    inst.last_cyc[this.execute_ind] = (int)(this.clock.count() - 1);
                    writeBack.add(inst);
                }
            }

            List < data_instr > execute_elgible = new ArrayList < data_instr > ();

            if (reader.size() != 0)
            {
                completed = false;
                List < data_instr > excute = new ArrayList < data_instr > ();
                for (int i = 0; i < reader.size(); i++)
                {
                    data_instr inst = reader.get(i);
                    if (inst.last_cyc[this.read_ind] < clock.count())
                    {
                        List < src_val > sourceList = inst.obt_src_reg();
                        if (sourceList != null)
                        {
                            boolean hasRAW = false;
                            for (int j = 0; j < sourceList.size(); j++)
                            {
                                if (this.fu.isRAWHazardPresent(inst) == true)
                                {
                                    hasRAW = true;
                                }
                            }
                            if (hasRAW == true)
                            {
                                inst.Read_Aft_Write_ha = true;
                            }
                            else
                            {
                                excute.add(inst);
                            }
                        }
                        else
                        {
                            excute.add(inst);
                        }
                    }
                }
                for (int i = 0; i < excute.size(); i++)
                {
                    data_instr inst = excute.get(i);
                    List < src_val > sourceReg = inst.obt_src_reg();
                    if (sourceReg != null)
                    {
                        if (sourceReg.size() > 0)
                        {
                            src_val reg = sourceReg.get(0);
                            String regName = reg.get_src();
                            reg.st_val(registers.readFrom(regName));
                        }
                        if (sourceReg.size() > 1)
                        {
                            src_val reg = sourceReg.get(1);
                            String regName = reg.get_src();
                            reg.st_val(registers.readFrom(regName));
                        }
                    }

                    inst.setSource1Ready(false);
                    inst.setSource2Ready(false);

                    inst.last_cyc[this.read_ind] = (int)(this.clock.count() - 1);

                    inst.exec_inst();


                    if (inst.instt == inst_type.ConditionalBranch)
                    {

                        to_stall = false;
                        if (inst instanceof br_eq)
                        {
                            br_eq bq = (br_eq) inst;
                            if (bq.obt_res())
                            {
                                flushing = true;
                                String label = bq.getBranchToLabel();
                                pc = runMgr.get_addr_label(label);
                            }
                        }
                        else if (inst instanceof br_not_eq)
                        {
                            br_not_eq bne = (br_not_eq) inst;
                            if (bne.getComparedResult())
                            {
                                flushing = true;
                                String label = bne.getBranchToLabel();
                                pc = runMgr.get_addr_label(label);
                            }
                        }

                        branch.add(inst);

                    }
                    else
                    {

                        switch (inst.func_unit)
                        {

                            case FPAdder:
                                {
                                    inst.last_cyc[this.execute_ind] = (int)(configMgr.get_add_Cycles() + clock.count() - 1);
                                    execute.add(inst);
                                }
                                break;
                            case FPDivider:
                                {
                                    inst.last_cyc[this.execute_ind] = (int)(configMgr.get_divider_Cycles() + clock.count() - 1);
                                    execute.add(inst);
                                }
                                break;
                            case func_multr:
                                {
                                    inst.last_cyc[this.execute_ind] = (int)(configMgr.get_mult_Cycles() + clock.count() - 1);
                                    execute.add(inst);
                                }
                                break;
                            case nier:
                                {
                                    inst.last_cyc[this.execute_ind] = (int)(1 + clock.count() - 1);
                                    execute.add(inst);
                                }
                                break;
                            case Ldunt:
                                {
                                    execute_elgible.add(inst);
                                    execute.add(inst);
                                }
                                break;
                            default:
                                System.out.println(" Unknown Functional unit: " + inst.func_unit);
                                break;
                        } //end of switch

                    } //end of else

                    reader.remove(inst);

                } //end of loop
            }

            if (issuer.size() != 0 && stall == false)
            {
                completed = false;
                List < data_instr > readElgible = new ArrayList < data_instr > ();

                for (int i = 0; i < issuer.size(); i++)
                {

                    data_instr inst = issuer.get(i);

                    if (flushing)
                    {
                        issuer.remove(inst);
                        inst.last_cyc[this.issue_ind] = (int)(this.clock.count() - 1);
                        flushed.add(inst);
                        continue;
                    }

                    if (inst instanceof halt)
                    {
                        haltBranch.add(inst);
                        continue;
                    }

                    if (inst instanceof jump)
                    {
                        jump jumpInst = (jump) inst;
                        String jumpLbl = jumpInst.gt_jp_to();
                        haltBranch.add(inst);
                        pc = runMgr.get_addr_label(jumpLbl);
                        flushing = true;
                        continue;
                    }

                    if (inst.begin_cyc[this.issue_ind] < clock.count())
                    {
                        if (fu.isAvailable(inst.func_unit) == false)
                        {
                            inst.struct_hazard = true;
                            continue;
                        }
                        if (inst.gt_dest_reg() == null)
                        {
                            readElgible.add(inst);
                        }
                        else if (fu.isWAWHazard(inst.gt_dest_reg().get_dest_loc()) == false)
                        {
                            readElgible.add(inst);
                        }
                        else
                        {
                            inst.Write_Aft_Write_ha = true;
                        }
                    }
                }
                for (int i = 0; i < readElgible.size(); i++)
                {
                    data_instr inst = readElgible.get(i);
                    if (inst.instt == inst_type.ConditionalBranch)
                    {
                        to_stall = true;
                    }
                    funct_unt_stats st = fu.getFunctionalUnit(inst);
                    inst.funct_stat = st;
                    inst.last_cyc[this.read_ind] = (int)(this.clock.count() + 1 - 1);
                    inst.last_cyc[this.issue_ind] = (int)(this.clock.count() - 1);
                    issuer.remove(inst);
                    reader.add(inst);
                }
                for (int i = 0; i < haltBranch.size(); i++)
                {
                    data_instr inst = haltBranch.get(i);
                    issuer.remove(inst);
                }
            }

            if (fetcher.size() == 0 && stall == false)
            {
                data_instr inst = runMgr.get_instr_addr(pc);
                if (inst != null)
                {
                    int clockCycles = this.iCache.getInst(pc);
                    completed = false;
                    inst.last_cyc[this.fetch_ind] = (int)(clock.count() + clockCycles - 1);
                    pc = pc + 1;
                    inst.instruct_issue = Instrcution_issue;
                    Instrcution_issue = Instrcution_issue + 1;
                    fetcher.add(inst);
                }
            }
            else if (stall == false)
            {
                completed = false;
                data_instr inst = fetcher.get(0);
                if (issuer.size() == 0 && inst.last_cyc[this.fetch_ind] < clock.count())
                {
                    fetcher.remove(inst);
                    inst.last_cyc[this.fetch_ind] = (int)(clock.count() - 1);
                    if (flushing == false)
                    {
                        inst.last_cyc[this.issue_ind] = (int)(clock.count() + 1 - 1);
                        issuer.add(inst);
                    }
                    else
                    {
                        flushing = false;
                        flushed.add(inst);
                    }
                    data_instr newinst = runMgr.get_instr_addr(pc);

                    if (newinst != null)
                    {
                        int clockCycles = this.iCache.getInst(pc);
                        completed = false;
                        newinst.last_cyc[this.fetch_ind] = (int)(clock.count() + clockCycles - 1);
                        newinst.instruct_issue = Instrcution_issue;
                        Instrcution_issue = Instrcution_issue + 1;
                        fetcher.add(newinst);
                        pc = pc + 1;
                    }
                }
            }

            for (int i = 0; i < flushed.size(); i++)
            {
                data_instr inst = flushed.get(i);
                instruction_completed.add(inst);
            }

            for (int i = 0; i < branch.size(); i++)
            {
                data_instr inst = branch.get(i);
                inst.last_cyc[this.read_ind] = (int)(clock.count() - 1);
                fu.writeToFunctionalStatus(inst);

                instruction_completed.add(inst);
            }

            for (int i = 0; i < haltBranch.size(); i++)
            {
                data_instr inst = haltBranch.get(i);
                inst.last_cyc[this.issue_ind] = (int)(clock.count() - 1);
                issuer.remove(inst);
                instruction_completed.add(inst);
            }

            fetch_Word = new ArrayList < data_instr > ();
            for (int i = 0; i < execute_elgible.size(); i++)
            {
                data_instr inst = execute_elgible.get(i);
                if (inst instanceof load)
                {
                    long addressvalue = inst.address;
                    DCacheInfo info = dCache.getData(addressvalue);
                    inst.last_cyc[this.execute_ind] = (int)(clock.count() + info.getClockCycles() - 1);
                    int value = binary_converter.toInt(info.getData());
                    fetch_Word.add(inst);
                    inst.gt_dest_reg().set_val(value);
                }
                else if (inst instanceof store_data)
                {
                    long addressvalue = inst.address;
                    int numCycles = dCache.updateValue(addressvalue, "10000000100000001000000010000000");
                    inst.last_cyc[this.execute_ind] = (int)(clock.count() + numCycles - 1);
                    fetch_Word.add(inst);
                }
                else if (inst instanceof load_word)
                {
                    long addressvalue = inst.address;
                    DCacheInfo info = dCache.getData(addressvalue);
                    inst.last_cyc[this.execute_ind] = (int)(clock.count() + info.getClockCycles() - 1);
                    int value = binary_converter.toInt(info.getData());
                    inst.gt_dest_reg().set_val(value);
                }
                else if (inst instanceof store_word)
                {
                    long addressvalue = inst.address;
                    List < src_val > srcReg = inst.obt_src_reg();
                    String defaultValue = "10000000";
                    if (srcReg != null)
                    {
                        int val = srcReg.get(0).get_val();
                        defaultValue = binary_converter.to_binary(val);
                    }
                    int numCycles = dCache.updateValue(addressvalue, defaultValue);
                    inst.last_cyc[this.execute_ind] = (int)(clock.count() + numCycles - 1);
                }
            }

            for (int i = 0; i < elgible.size(); i++)
            {
                data_instr inst = elgible.get(i);
                writeBack.remove(inst);
                if (inst.gt_dest_reg() != null)
                {
                    String regName = inst.gt_dest_reg().get_dest_loc();
                    int val = inst.gt_dest_reg().getValue();
                    registers.writeTo(regName, val);
                }
                instruction_completed.add(inst);
                fu.writeToFunctionalStatus(inst);
            }
            if (completed == true)
            {
                dCache.updateDataToMemory();
                mem_parse.getInstance().pushMemDataToFile();
                StoretoFile(instruction_completed);
                break;
            }
            if (to_stall == true)
            {
                stall = true;
            }
            if (to_stall == false)
            {
                stall = false;
            }
            clock.increments();
            for (int i = 0; i < fetch_Word.size(); i++)
            {
                data_instr inst = fetch_Word.get(i);
                if (inst instanceof load)
                {
                    long addressvalue = inst.address;
                    DCacheInfo info = dCache.getData(addressvalue + 4);
                    inst.last_cyc[this.execute_ind] = inst.last_cyc[this.execute_ind] + info.getClockCycles();
                    int value = binary_converter.toInt(info.getData());
                    inst.gt_dest_reg().set_val(value);
                }
                else if (inst instanceof store_data)
                {
                    long addressvalue = inst.address;
                    int numCycles2 = dCache.updateValue(addressvalue + 4, "10000000100000001000000010000000");
                    inst.last_cyc[this.execute_ind] = inst.last_cyc[this.execute_ind] + numCycles2;
                }
            }
        }
    }

    private class IssueComparator implements Comparator < data_instr >
    {
        @Override
        public int compare(data_instr arg0, data_instr arg1)
        {
            return arg0.compareTo(arg1);
        }

    }

    public void StoretoFile(List < data_instr > totalInstructions)
    {
        StringBuilder sb = new StringBuilder();
        Collections.sort(totalInstructions, new IssueComparator());

        String Header = String.format(output_syntax, header_array);
        System.out.println(Header);
        sb.append(Header).append(System.lineSeparator());

        for (int i = 0; i < totalInstructions.size(); i++)
        {
            data_instr inst = totalInstructions.get(i);
            if (i == totalInstructions.size() - 1 && inst.instt.equals(inst_type.HALT))
                inst.last_cyc[1] = 0;
            System.out.println(inst.get_output());
            sb.append(inst.get_output()).append(System.lineSeparator());
        }
        System.out.println(this.iCache.getICacheStatistics());
        System.out.println(this.dCache.getDCacheStatistics());
        sb.append(this.iCache.getICacheStatistics()).append(System.lineSeparator());
        sb.append(this.dCache.getDCacheStatistics()).append(System.lineSeparator());

        result_write.getInstance().writeToFile(sb.toString());

    }

}